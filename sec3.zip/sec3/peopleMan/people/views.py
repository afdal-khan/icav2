from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
from .models import People
from .forms import PeopleForm

# Create your views here.
def index(request):
    allRecords = People.objects.all()
    return render(request, 'list.html', {
        'peoples': allRecords
    })


from django.http import HttpResponseRedirect

class RecordView(View):

    def get(self, request):
        PepForm = PeopleForm()
        return render(request, 'add.html', {
            'form' : PepForm
        })

    def post(self, request):
        PepForm = PeopleForm(request.POST, request.FILES)
        if PepForm.is_valid():
            PepForm.save()
            return HttpResponseRedirect("/?oper=cat&res=true")
        # Else request was invalid
        return render(request, 'add.html', {
            'form' : PepForm
        })
