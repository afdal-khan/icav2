from django.db import models
import uuid
from django.db.models import (
    UUIDField,
    CharField,
    TextField,
    IntegerField,
    BooleanField,
    DateTimeField,
    ImageField
)
# Create your models here.
class People(models.Model):
    id = UUIDField(primary_key=True,
    default=uuid.uuid4, editable=False)
    fname = CharField(max_length=100)
    lname = CharField(max_length=100)
    country = CharField(max_length=100)


